package com.example.recuperacionrodrigotapiador.ui.viewmodels

import androidx.lifecycle.ViewModel

class HomeViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}