package com.example.recuperacionrodrigotapiador.ui.viewmodels

import androidx.lifecycle.ViewModel

class FilterViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}