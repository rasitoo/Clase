package com.example.examenrodrigotapiador.ui.viewModels

import androidx.lifecycle.ViewModel

class UsersViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}