package com.example.examenrodrigotapiador.models

/**
 * @author Rodrigo
 * @date 21 febrero, 2025
 */
data class Day(
    val number: Int,
    val day: String
)
