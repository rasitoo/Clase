package com.example.examenrodrigotapiador.api

import com.example.examenrodrigotapiador.models.User

/**
 * @author Rodrigo
 * @date 21 febrero, 2025
 */
data class RemoteResult (
    val users: List<User>
)