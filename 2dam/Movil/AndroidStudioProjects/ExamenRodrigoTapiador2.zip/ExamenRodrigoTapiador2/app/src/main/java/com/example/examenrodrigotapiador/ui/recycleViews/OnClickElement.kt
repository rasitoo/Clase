package com.example.examenrodrigotapiador.ui.recycleViews

/**
 * @author Rodrigo
 * @date 21 febrero, 2025
 */
interface OnClickElement {
    fun onclickElem(id: Int)
}