package com.example.examenrodrigotapiador.ui.viewModels

import androidx.lifecycle.ViewModel

class HomeViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}