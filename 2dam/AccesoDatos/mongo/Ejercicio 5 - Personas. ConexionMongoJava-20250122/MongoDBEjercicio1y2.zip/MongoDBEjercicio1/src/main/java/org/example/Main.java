package org.example;


import com.mongodb.client.*;
import org.bson.Document;
import java.util.Arrays;
import static com.mongodb.client.model.Filters.eq;
import static com.mongodb.client.model.Sorts.descending;

public class Main {
    public static void main(String[] args) {
        Operaciones.consulta();
    }
}