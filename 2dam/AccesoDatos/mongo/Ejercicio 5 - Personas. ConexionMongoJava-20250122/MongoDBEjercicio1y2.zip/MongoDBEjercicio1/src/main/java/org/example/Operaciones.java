package org.example;

import com.mongodb.client.*;
import org.bson.Document;
import java.util.Arrays;
import static com.mongodb.client.model.Filters.eq;
import static com.mongodb.client.model.Sorts.descending;

public class Operaciones {

    public static void consulta() {
        // Conectar a MongoDB
        String uri = "mongodb://localhost:27017";
        MongoClient mongoClient = MongoClients.create(uri);
        // Seleccionar la base de datos y la colección
        MongoDatabase database = mongoClient.getDatabase("ejemplos");
        MongoCollection<Document> collection = database.getCollection("amigos");
        // Mostrar las colecciones para verificar que existe 'amigos'
        System.out.println("Colecciones disponibles:");
        for (String name : database.listCollectionNames()) {
            System.out.println(name);
        }
        // Consulta para obtener personas con 18 años
        FindIterable<Document> resultados = collection.find(eq("Edad", 18));
        // Verificar si hay resultados
        if (resultados.iterator().hasNext()) {
            System.out.println("Se encontraron resultados para la consulta.");
        } else {
            System.out.println("No se encontraron resultados para la consulta.");
        }
        // Procesar resultados
        try {
            for (Document doc : resultados) {
                // System.out.println("Documento encontrado: " + doc.toJson()); // Mostrar documento completo

                String nombre = doc.getString("Nombre");
                String apellidos = doc.getString("Apellidos");
                int edad = doc.getInteger("Edad");

                System.out.println("Nombre: " + nombre + " " + apellidos);
                System.out.println("Edad: " + edad);
                System.out.println("Los Amigos de " + nombre + " (ordenados por edad descendente):");

                // Obtener y ordenar los amigos por edad descendente
                Document[] amigos = doc.getList("Amigos", Document.class).toArray(new Document[0]);
                Arrays.sort(amigos, (a, b) -> b.getInteger("Edad") - a.getInteger("Edad"));

                for (Document amigo : amigos) {
                    System.out.println("  - " + amigo.getString("Nombre") + " (" + amigo.getInteger("Edad") + " años)");
                }
                System.out.println("--------------------------------------");
            }
        } catch (Exception e) {
            System.out.println("Error procesando los documentos: " + e.getMessage());
        }
        // Cerrar la conexión
        mongoClient.close();
    }
}
