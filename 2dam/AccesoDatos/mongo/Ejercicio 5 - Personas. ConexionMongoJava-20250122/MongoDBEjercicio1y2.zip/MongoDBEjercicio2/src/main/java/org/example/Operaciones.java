package org.example;

import com.mongodb.client.*;
import org.bson.Document;
import java.util.Arrays;
import static com.mongodb.client.model.Filters.eq;
import static com.mongodb.client.model.Sorts.descending;

public class Operaciones {

    public static void consultacursor() {

        // Crear un cliente de MongoDB
        String uri = "mongodb://localhost:27017";
        MongoClient mongoClient = MongoClients.create(uri);

        // Seleccionar la base de datos
        MongoDatabase database = mongoClient.getDatabase("ejemplos");

        // Seleccionar la colección
        MongoCollection<Document> collection = database.getCollection("amigos");

        // Realizar la consulta para las personas con Edad 18
        MongoCursor<Document> cursor = collection.find(eq("Edad", 18)).iterator();

        System.out.println(" LOS ALUMNOS CON EDAD 18 USANDO CURSORES, ES DECIR, HASNEXT ");
        System.out.println(" ---------------------------------------------------------- ");
        // Iterar sobre los resultados y mostrarlos
        try {
            while (cursor.hasNext()) {
                Document doc = cursor.next();
                System.out.println(doc.toJson());
            }
        } finally {
            cursor.close();
            mongoClient.close();
        }
    }
    public static void consultasincursor() {
            // Crear un cliente de MongoDB
            String uri = "mongodb://localhost:27017";
            MongoClient mongoClient = MongoClients.create(uri);

            // Seleccionar la base de datos
            MongoDatabase database = mongoClient.getDatabase("ejemplos");

            // Seleccionar la colección
            MongoCollection<Document> collection = database.getCollection("amigos");
                // Consulta para obtener personas con 18 años
            FindIterable<Document> resultados = collection.find(eq("Edad", 18));
            // Verificar si hay resultados
            if (resultados.iterator().hasNext()) {
                System.out.println("Se encontraron resultados para la consulta.");
            } else {
                System.out.println("No se encontraron resultados para la consulta.");
            }
            // Procesar resultados
            System.out.println(" LOS ALUMNOS CON EDAD 18 SIN USAR CURSORES, ES DECIR, COMO EL EJERCICIO 1 ");
            System.out.println(" ----------------------------------------------------------------------- ");
            try {
                for (Document doc : resultados) {
                    // System.out.println("Documento encontrado: " + doc.toJson()); // Mostrar documento completo

                    String nombre = doc.getString("Nombre");
                    String apellidos = doc.getString("Apellidos");
                    int edad = doc.getInteger("Edad");

                    System.out.println("Nombre: " + nombre + " " + apellidos);
                    System.out.println("Edad: " + edad);
                    System.out.println("Los Amigos de " + nombre + " (ordenados por edad descendente):");

                    // Obtener y ordenar los amigos por edad descendente
                    Document[] amigos = doc.getList("Amigos", Document.class).toArray(new Document[0]);
                    Arrays.sort(amigos, (a, b) -> b.getInteger("Edad") - a.getInteger("Edad"));

                    for (Document amigo : amigos) {
                        System.out.println("  - " + amigo.getString("Nombre") + " (" + amigo.getInteger("Edad") + " años)");
                    }
                    System.out.println("--------------------------------------");
                }
            } catch (Exception e) {
                System.out.println("Error en los documentos: " + e.getMessage());
            }
            // Cerrar la conexión
            mongoClient.close();

    }
}

