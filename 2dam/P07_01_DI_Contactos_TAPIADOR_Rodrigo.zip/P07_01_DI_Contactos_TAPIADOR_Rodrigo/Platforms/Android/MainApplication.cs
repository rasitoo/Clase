﻿using Android.App;
using Android.Runtime;

namespace P07_01_DI_Contactos_TAPIADOR_rodrigo;

[Application]
public class MainApplication : MauiApplication
{
    public MainApplication(IntPtr handle, JniHandleOwnership ownership)
        : base(handle, ownership)
    {
    }

    protected override MauiApp CreateMauiApp() => MauiProgram.CreateMauiApp();
}
