﻿using Foundation;

namespace P07_01_DI_Contactos_TAPIADOR_rodrigo;

[Register("AppDelegate")]
public class AppDelegate : MauiUIApplicationDelegate
{
    protected override MauiApp CreateMauiApp() => MauiProgram.CreateMauiApp();
}
