﻿using System.Windows.Controls;

namespace ExamenRodrigoTapiador.UI.Controls
{
    /// <summary>
    /// Lógica de interacción para ListViewImages.xaml
    /// </summary>
    public partial class ListViewImages : UserControl
    {
        public ListViewImages()
        {
            InitializeComponent();
        }
    }
}
